#!/bin/bash

cp /sd/ov/axi_timer.dtbo 	/lib/firmware/dev_4.dtbo
cp /sd/ov/axi_pwm.dtbo 	/lib/firmware/dev_1.dtbo
cp /sd/ov/axi_sw.dtbo 		/lib/firmware/dev_3.dtbo
cp /sd/ov/axi_random.dtbo /lib/firmware/dev_2.dtbo
cp /sd/ov/axi_id_reg.dtbo 	/lib/firmware/axi_id_reg.dtbo
insmod /sd/device_drivers.ko
insmod /sd/device_attacher.ko
echo 8 > /proc/sys/kernel/printk
